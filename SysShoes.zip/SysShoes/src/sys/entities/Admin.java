    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.entities;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *¢¢¢
 * @author udesc
 */
public class Admin {
    
    private String nome;
    private String CPF;
    private static Admin exists = null;
    private static String senha;
    private static String chars = "jhASD*&yd1k2ujdhASIDH1i2h3p*(!O!U#LJHSAD(!@*#_ASKLJD!*&QP{WEO><AMSXCVBN!@I#U";
    private int ID;
    
    private Admin(String nome, String CPF, String senha) {
        this.nome = nome;
        this.CPF = CPF;
        this.senha = senha;
        this.ID = 1261393937;
        
        java.io.File arquivo = new java.io.File("first_log.txt");
        try {
            java.io.PrintWriter out = new java.io.PrintWriter(new java.io.BufferedWriter(new java.io.FileWriter("first_log.out")));
            out.write("Admin account:\n"
                    + "ID: " + this.ID + "\n"
                            + "Password: " + senha + "\n");
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }    
        
        
    }
    
    /**
     *
     * @param nome
     * @param ID
     * @param CPF
     * @return
     */
    public static Admin instanceAdmin(String nome, int ID, String CPF){
        if(exists == null){
            String senha = "";
            java.util.Random r = new java.util.Random();
            for(int i=0; i<30; i++){
                senha += chars.charAt(r.nextInt(128)%chars.length());
            }
            exists = new Admin(nome, CPF, senha);
            
        }
        return exists;
    }
    
    /**
     * @param senha
     * @return the senha
     */
    
    public static boolean compareSenha(String senha) {
        return senha.equals(Admin.senha);
    }
    
}
