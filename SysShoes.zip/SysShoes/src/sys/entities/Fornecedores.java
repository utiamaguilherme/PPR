/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.entities;

/**
 *
 * @author guilhermeutiama
 */
public class Fornecedores {
    private int ID;
    private String nome;
    private String CNPJ;
    private static int gID=0;
    
    public Fornecedores(String nome, String CNPJ){
        this.CNPJ = CNPJ;
        this.ID = gID;
        gID++;
        this.nome = nome;
    }

    public String toString(){
        return "ID da Empresa: "+this.getID()+"\nNome: "+this.getNome()+"\nCNPJ: "+this.getCNPJ();
    }
    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the CNPJ
     */
    public String getCNPJ() {
        return CNPJ;
    }
}
