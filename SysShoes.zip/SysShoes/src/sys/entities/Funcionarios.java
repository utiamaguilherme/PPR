/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.entities;

/**
 *
 * @author udesc
 */
public class Funcionarios {
    private String nome;
    private static int gID=0;
    private int ID;
    private String CPF;
    private String senha;
//    private
            
    public Funcionarios(String nome, String CPF, String senha){
        this.CPF = CPF;
        this.ID = gID;
        this.nome = nome;
        this.senha = senha;
        gID++;
    }
    
    Funcionarios(String nome, String CPF){
        this.CPF = CPF;
        this.nome = nome;
    }
    
    public String toString(){
        return "ID do Funcionario: "+this.getID()+"\nNome: "+this.getNome()+"\nCPF: "+this.getCPF();
    }
    
    
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @return the CPF
     */
    public String getCPF() {
        return CPF;
    }
    
    public boolean compareSenha(String senha){
        return senha.equals(this.senha);
    }
        
            
}
