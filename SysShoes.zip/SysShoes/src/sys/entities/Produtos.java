/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.entities;

import java.awt.Color;

/**
 *
 * @author udesc
 */
public class Produtos {
    private static int gID=0;
    private int ID;
    private String nome;
    private Color cor;
    private Color secundaria;
    private double preco;
    
    public Produtos(String nome, double preco, Color cor, Color secundaria){
        this.ID = gID;
        this.cor = cor;
        this.nome = nome;
        this.secundaria = secundaria;
        this.preco = preco;
        gID++;
    }
    
    @Override
    public String toString(){
        return "ID do produto: "+this.getID()+"\nNome: "+this.getNome()+"\nCor primaria: "+this.getCor()+
                "\nCor Secundaria: "+this.getSecundaria()+"\nPreço: "+this.getPreco();
                
    }
    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the cor
     */
    public Color getCor() {
        return cor;
    }

    /**
     * @return the secundaria
     */
    public Color getSecundaria() {
        return secundaria;
    }

    /**
     * @return the preco
     */
    public double getPreco() {
        return preco;
    }
}
