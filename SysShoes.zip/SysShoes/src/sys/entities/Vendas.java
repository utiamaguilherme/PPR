/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.entities;

/**
 *
 * @author udesc
 */
public class Vendas {
    private int IDVendedor;
    private int IDCliente;
    private int IDProdutos;
    
    public Vendas(int IDVendedor, int IDCliente, int IDProdutos){
        this.IDCliente = IDCliente;
        this.IDProdutos = IDProdutos;
        this.IDVendedor = IDVendedor;
    }

    /**
     * @return the IDVendedor
     */
    public int getIDVendedor() {
        return IDVendedor;
    }

    /**
     * @return the IDCliente
     */
    public int getIDCliente() {
        return IDCliente;
    }

    /**
     * @return the IDProdutos
     */
    public int getIDProdutos() {
        return IDProdutos;
    }
    
    @Override
    public String toString(){
        return "ID Vendedor: "+this.getIDVendedor()+"\nID CLiente: "+this.getIDCliente()+"\nID Produto: "+this.getIDProdutos();
    }
}
