/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.entities;

import java.util.Vector;

/**
 *
 * @author udesc
 */
public class Clientes {
    private String nome;
    private static int gID=0;
    private int ID;
    private String CPF;
    private String telefone;
//    private HashMap<int,> historico;
    
    public Clientes(String nome, String CPF, String telefone){
        this.CPF = CPF;
        this.ID = Clientes.gID;
        this.nome = nome;
        this.telefone = telefone;
        Clientes.gID++;
    }

    public String toString(){
        return "ID: "+this.getID()+"\nNome: "+this.getNome()+"\nCPF: "+this.getCPF()+"\nTelefone: "+this.getTelefone();
    }
    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @return the ID
     */
    public int getID() {
        return this.ID;
    }

    /**
     * @return the CPF
     */
    public String getCPF() {
        return CPF;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }
    
}
