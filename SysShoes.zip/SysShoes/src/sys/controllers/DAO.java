/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.controllers;

import sys.entities.Vendas;
import sys.entities.Produtos;
import sys.entities.Funcionarios;
import sys.entities.Fornecedores;
import sys.entities.Clientes;
import sys.entities.Admin;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author udesc
 */

public class DAO {
    
    private ArrayList<Clientes> cliente;
    private ArrayList<Funcionarios> funcionario;
    private ArrayList<Produtos> produto;
    private ArrayList<Vendas> vendas;
    private ArrayList<Fornecedores> fornecedor;
    private static DAO dao = null;
    
    private DAO(){
        cliente = new ArrayList<>();
        funcionario = new ArrayList<>();
        produto = new ArrayList<>();
        vendas = new ArrayList<>();
        fornecedor = new ArrayList<>();
    }
    
    /**
     *
     * @return
     */
    public static DAO getInstance(){
        if(getDao() == null){
            dao = new DAO();
        }
        return getDao();
    }
    
    public void AddCliente(Clientes cliente){
        this.cliente.add(cliente);
    }
    
    public void DelCliente(Clientes cliente){
        this.cliente.remove(cliente);
    }
    
    public void AddFuncionario(Funcionarios func){
        System.out.println("Digite sua senha:");
        Scanner scan = new Scanner(System.in);
        String id;
        id = scan.nextLine();
        if(Admin.compareSenha(id))
            this.funcionario.add(func);
    }
    
    public void DelFuncionario(Funcionarios func){
        System.out.println("Digite sua senha:");
        Scanner scan = new Scanner(System.in);
        String id;
        id = scan.nextLine();
        if(Admin.compareSenha(id))
            this.funcionario.remove(func);
    }
    
    public void AddProdutos(Produtos prod){
        System.out.println("Digite sua senha:");
        Scanner scan = new Scanner(System.in);
        String id;
        id = scan.nextLine();
        if(Admin.compareSenha(id))
            this.produto.add(prod);
    }
    
    public void DelProdutos(Produtos prod){
        System.out.println("Digite sua senha:");
        Scanner scan = new Scanner(System.in);
        String id;
        id = scan.nextLine();
        if(Admin.compareSenha(id))
            this.produto.remove(prod);
    }
    
    public void AddFornecedores(Fornecedores fornecedor){
        System.out.println("Digite sua senha:");
        Scanner scan = new Scanner(System.in);
        String id;
        id = scan.nextLine();
        if(Admin.compareSenha(id))
            this.getFornecedor().add(fornecedor);
    }
    
    public void DelFornecedor(Fornecedores fornecedor){
        System.out.println("Digite sua senha:");
        Scanner scan = new Scanner(System.in);
        String id;
        id = scan.nextLine();
        if(Admin.compareSenha(id))
            this.getFornecedor().add(fornecedor);
    }

    public void AddVendas(Vendas venda){
        this.vendas.add(venda);
    }
    
    public void DelVendas(Vendas venda){
        this.vendas.remove(venda);
    }
    /**
     * @return the cliente
     */
    public Clientes getCliente(int ID) {
        for(Clientes c : cliente)
            if(c.getID() == ID)
                return c;
        return null;
    }

    /**
     * @return the funcionario
     */
    public Funcionarios getFuncionario(int ID){
        for(Funcionarios f : funcionario)
            if(f.getID() == ID)
                return f;
        return null;
    }

    /**
     * @return the produto
     */
    public Produtos getProduto(int ID){
        for(Produtos p : produto)
            if(p.getID() == ID)
                return p;
        return null;
    }

    /**
     * @return the vendas
     */
    public Vendas getVendas(int IDf, int IDc, int IDp) {
        for(Vendas v : vendas)
            if(v.getIDVendedor() == IDf)
                if(v.getIDProdutos() == IDp)
                    if(v.getIDCliente() == IDc)
                        return v;
        return null;
    }

    /**
     * @return the dao
     */
    public static DAO getDao() {
        return dao;
    }
    
    public void RelatorioVendas(){
        System.out.println("Relatorio de vendas:");
        for(int i=0; i<this.vendas.size(); i++){
            System.out.print(i+".");
            System.out.println(vendas.get(i));
            System.out.println();
        }
    }
    
    public String showVendas(){
        String out = "";
        for(int i=0; i<this.vendas.size(); i++){
            out = out + ""+i+".\n"+vendas.get(i).toString() + "\n\n";
        }
        return out;
    }
    
    public void RelatorioFornecedores(){
        System.out.println("Relatorio de fornecedores:");
        for(int i=0; i<this.getFornecedor().size(); i++){
            System.out.print(i+".");
            System.out.println(getFornecedor().get(i));
            System.out.println();
        }
    }
    
    public String showFornecedores(){
        String out = "";
        for(int i=0; i<this.getFornecedor().size(); i++){
            out = out + ""+i+".\n"+getFornecedor().get(i).toString() + "\n\n";
        }
        return out;
    }
    
    public void RelatorioProdutos(){
        System.out.println("Relatorio de Produtos:");
        for(int i=0; i<this.produto.size(); i++){
            System.out.print(i+".");
            System.out.println(produto.get(i));
            System.out.println();
        }
    }
    
    public String showProdutos() {
        String out = "";
        for(int i=0; i<this.produto.size(); i++){
            out = out + ""+i+".\n"+produto.get(i).toString() + "\n\n";
        }
        return out;
    }
    
    public void RelatorioClientes(){
        System.out.println("Relatorio de Clientes:");
        for(int i=0; i<this.cliente.size(); i++){
            System.out.print(i+".");
            System.out.println(cliente.get(i));
            System.out.println();
        }
    }
    
    public String showClientes(){
        String out = "";
        for(int i=0; i<this.cliente.size(); i++){
            out = out + ""+i+".\n"+cliente.get(i).toString() + "\n\n";
        }
        return out;
    }
    
    public void RelatorioFuncionarios(){
        System.out.println("Relatorio de Funcionarios:");
        for(int i=0; i<this.funcionario.size(); i++){
            System.out.print(i+".");
            System.out.println(funcionario.get(i));
            System.out.println();
        }
    }
    
    public String showFuncionarios(){
        String out = "";
        for(int i=0; i<this.funcionario.size(); i++){
            out = out + ""+i+".\n"+funcionario.get(i).toString() + "\n\n";
        }
        return out;
    }
    
    public void BuscarVenda(Vendas prod){
        for(Vendas v : vendas)
            if(v.equals(prod))
                System.out.println(v);
            //tem que ver aqui
        
    }
    
    public void BuscarFuncionario(Funcionarios func){
        for(Funcionarios f : funcionario)
            if(f.equals(func))
                System.out.println(f);
        
    }
    
    public void BuscarCliente(Clientes cliente){
        for(Clientes c : this.cliente)
            if(c.equals(cliente))
                System.out.println(c);
    }
    
    public void BuscarProduto(Produtos prod){
        for(Produtos p : produto)
            if(p.equals(prod))
                System.out.println(p);
    }
    
    public void BuscarFornecedor(Fornecedores forn){
        for(Fornecedores f : getFornecedor())
            if(f.equals(forn))
                System.out.println(f);
    }

    /**
     * @return the fornecedor
     */
    public ArrayList<Fornecedores> getFornecedor() {
        return fornecedor;
    }
   

    /**
     * @return the fornecedor
     */
    public Fornecedores getFornecedor(int ID) {
        for(Fornecedores p : fornecedor)
            if(p.getID() == ID)
                return p;
        return null;
    }
    
}
