/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.data.dataTypes;

/**
 *
 * @author 3
 */
public enum Operation {
    ADD, REMOVE;
}
